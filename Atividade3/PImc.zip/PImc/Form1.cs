﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double pesoAtual, altura, imc;

        private void btnCalc_Click(object sender, EventArgs e)
        {
            altura = Convert.ToDouble(HTextBox.Text);
            pesoAtual = Convert.ToDouble(PATextBox.Text);
            imc = pesoAtual / (altura * altura);
            imc = Math.Round(imc,1);
            if (imc < 18.5)
                MessageBox.Show("Magreza");
            else if (imc <= 24.9)
                MessageBox.Show("Normal");
            else if (imc <= 29.9)
                MessageBox.Show("Sobrepeso");
            else if (imc <= 39.9)
                MessageBox.Show("Obesidade");
            else
                MessageBox.Show("Obesidade grave");
                IMCtextBox.Text = imc.ToString();
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            HTextBox.Clear();
            PATextBox.Clear();
            IMCtextBox.Clear(); 
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void PATextBox_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(PATextBox.Text, out pesoAtual) || pesoAtual <= 0)
             { 
            MessageBox.Show("Peso inválido");
            PATextBox.Focus();
              }
        }

        private void HTextBox_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(HTextBox.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura inválida");
                HTextBox.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
