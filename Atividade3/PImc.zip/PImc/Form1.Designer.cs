﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPA = new System.Windows.Forms.Label();
            this.lblH = new System.Windows.Forms.Label();
            this.lblIMC = new System.Windows.Forms.Label();
            this.IMCtextBox = new System.Windows.Forms.TextBox();
            this.PATextBox = new System.Windows.Forms.MaskedTextBox();
            this.HTextBox = new System.Windows.Forms.MaskedTextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnLimp = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPA
            // 
            this.lblPA.AutoSize = true;
            this.lblPA.Location = new System.Drawing.Point(28, 62);
            this.lblPA.Name = "lblPA";
            this.lblPA.Size = new System.Drawing.Size(86, 20);
            this.lblPA.TabIndex = 0;
            this.lblPA.Text = "Peso Atual";
            // 
            // lblH
            // 
            this.lblH.AutoSize = true;
            this.lblH.Location = new System.Drawing.Point(28, 140);
            this.lblH.Name = "lblH";
            this.lblH.Size = new System.Drawing.Size(51, 20);
            this.lblH.TabIndex = 1;
            this.lblH.Text = "Altura";
            // 
            // lblIMC
            // 
            this.lblIMC.AutoSize = true;
            this.lblIMC.Location = new System.Drawing.Point(28, 219);
            this.lblIMC.Name = "lblIMC";
            this.lblIMC.Size = new System.Drawing.Size(38, 20);
            this.lblIMC.TabIndex = 2;
            this.lblIMC.Text = "IMC";
            // 
            // IMCtextBox
            // 
            this.IMCtextBox.Location = new System.Drawing.Point(120, 219);
            this.IMCtextBox.Name = "IMCtextBox";
            this.IMCtextBox.ReadOnly = true;
            this.IMCtextBox.Size = new System.Drawing.Size(232, 26);
            this.IMCtextBox.TabIndex = 10;
            this.IMCtextBox.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // PATextBox
            // 
            this.PATextBox.Location = new System.Drawing.Point(120, 62);
            this.PATextBox.Mask = "900.00";
            this.PATextBox.Name = "PATextBox";
            this.PATextBox.Size = new System.Drawing.Size(141, 26);
            this.PATextBox.TabIndex = 1;
            this.PATextBox.Validated += new System.EventHandler(this.PATextBox_Validated);
            // 
            // HTextBox
            // 
            this.HTextBox.Location = new System.Drawing.Point(120, 140);
            this.HTextBox.Mask = "0.00";
            this.HTextBox.Name = "HTextBox";
            this.HTextBox.Size = new System.Drawing.Size(141, 26);
            this.HTextBox.TabIndex = 2;
            this.HTextBox.Validated += new System.EventHandler(this.HTextBox_Validated);
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(41, 362);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(135, 63);
            this.btnCalc.TabIndex = 3;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnLimp
            // 
            this.btnLimp.Location = new System.Drawing.Point(217, 362);
            this.btnLimp.Name = "btnLimp";
            this.btnLimp.Size = new System.Drawing.Size(135, 63);
            this.btnLimp.TabIndex = 4;
            this.btnLimp.Text = "Limpar";
            this.btnLimp.UseVisualStyleBackColor = true;
            this.btnLimp.Click += new System.EventHandler(this.btnLimp_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(388, 362);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(135, 63);
            this.btnSair.TabIndex = 5;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(599, 549);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimp);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.HTextBox);
            this.Controls.Add(this.PATextBox);
            this.Controls.Add(this.IMCtextBox);
            this.Controls.Add(this.lblIMC);
            this.Controls.Add(this.lblH);
            this.Controls.Add(this.lblPA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPA;
        private System.Windows.Forms.Label lblH;
        private System.Windows.Forms.Label lblIMC;
        private System.Windows.Forms.TextBox IMCtextBox;
        private System.Windows.Forms.MaskedTextBox PATextBox;
        private System.Windows.Forms.MaskedTextBox HTextBox;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnLimp;
        private System.Windows.Forms.Button btnSair;
    }
}

