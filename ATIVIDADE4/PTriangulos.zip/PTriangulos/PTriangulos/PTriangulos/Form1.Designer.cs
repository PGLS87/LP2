﻿namespace PTriangulos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblA = new System.Windows.Forms.Label();
            this.lblB = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.btnValidar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.errLadoA = new System.Windows.Forms.ErrorProvider(this.components);
            this.errLadoB = new System.Windows.Forms.ErrorProvider(this.components);
            this.errLadoC = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errLadoA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errLadoB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errLadoC)).BeginInit();
            this.SuspendLayout();
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Location = new System.Drawing.Point(79, 110);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(83, 20);
            this.lblA.TabIndex = 0;
            this.lblA.Text = "Valor de A";
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Location = new System.Drawing.Point(79, 185);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(83, 20);
            this.lblB.TabIndex = 1;
            this.lblB.Text = "Valor de B";
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(79, 256);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(83, 20);
            this.lblC.TabIndex = 2;
            this.lblC.Text = "Valor de C";
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(193, 110);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(270, 26);
            this.txtA.TabIndex = 3;
            this.txtA.Validated += new System.EventHandler(this.txtA_Validated);
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(193, 185);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(270, 26);
            this.txtB.TabIndex = 4;
            this.txtB.Validated += new System.EventHandler(this.txtB_Validated);
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(193, 256);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(270, 26);
            this.txtC.TabIndex = 5;
            this.txtC.Validated += new System.EventHandler(this.txtC_Validated);
            // 
            // btnValidar
            // 
            this.btnValidar.Location = new System.Drawing.Point(83, 416);
            this.btnValidar.Name = "btnValidar";
            this.btnValidar.Size = new System.Drawing.Size(196, 80);
            this.btnValidar.TabIndex = 6;
            this.btnValidar.Text = "Validar";
            this.btnValidar.UseVisualStyleBackColor = true;
            this.btnValidar.Click += new System.EventHandler(this.btnValidar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(347, 416);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(196, 80);
            this.btnLimpar.TabIndex = 7;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(609, 416);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(196, 80);
            this.btnFechar.TabIndex = 8;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // errLadoA
            // 
            this.errLadoA.ContainerControl = this;
            // 
            // errLadoB
            // 
            this.errLadoB.ContainerControl = this;
            // 
            // errLadoC
            // 
            this.errLadoC.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(937, 563);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnValidar);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.lblA);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errLadoA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errLadoB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errLadoC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.Button btnValidar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.ErrorProvider errLadoA;
        private System.Windows.Forms.ErrorProvider errLadoB;
        private System.Windows.Forms.ErrorProvider errLadoC;
    }
}

