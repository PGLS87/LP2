﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvendas02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listboxVendas.Items.Clear();
        }

        private void btnVendas_Click(object sender, EventArgs e)
        {
            double[,] vendas = new double[2,4];
            int i, j;
            double totalmes = 0;
            double totalgeral = 0;
            string venda;
            string saida = "";

            for (i = 0; i < 2; i++) 
            {
                for (j = 0; j < 4; j++) 
                {
                    venda = Interaction.InputBox("Digite o valor da venda semanal");

                    if (venda == "")
                    {
                        return;
                    }
                    else if (!double.TryParse(venda, out vendas[i, j]))
                    {
                        MessageBox.Show("Adicione um número");
                        --j;
                    }
                    else if (j < 0)
                    {
                        MessageBox.Show("Adicione um número maior ou igual a zero");
                        --j;
                    }
                     
                }
                totalgeral += totalmes;   
            }

            for (i = 0; i < 2; i++)
            {
                saida = "";
                totalmes = 0;
                for (j = 0; j < 4; j++)
                {
                    saida = ($"Total do mês:  {i + 1}    Semana {j + 1}:  {vendas[i,j]}");
                    listboxVendas.Items.Add(saida);
                    totalmes += vendas[i,j];
                }
                listboxVendas.Items.Add($">> Total Mês:  {totalmes}");
                listboxVendas.Items.Add("----------------------");
                totalgeral += totalmes;
            }
            listboxVendas.Items.Add($">> Total Geral: {totalgeral}");
        }
    }
}
