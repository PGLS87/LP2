﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            string[] nomesmedicao = new string[10];
            int[] nomestamanho = new int[10];
            string saida = "";

            for (int i = 0; i < 10; i++)
            {
                nomes[i] = Interaction.InputBox("Digite o nome");
                if (nomes[i] == "" || nomes[i] == " ") 
                {
                    return;
                }
                else
                {
                    nomes[i].Trim();
                    nomesmedicao[i] = nomes[i];
                    nomesmedicao[i] = nomesmedicao[i].Replace(" ", "");
                    nomestamanho[i] = nomesmedicao[i].Length;
                }
            }
            for (int i = 0; i < 10; i++)
            {
                saida = ($"o nome:{nomes[i]} tem {nomestamanho[i]} caracteres");
                lstbxNomes.Items.Add(saida);
            }
        }
    }
}
