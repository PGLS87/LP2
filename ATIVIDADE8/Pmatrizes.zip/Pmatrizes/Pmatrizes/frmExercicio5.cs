﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            string[,] respostas = new string[3, 10];
            string[] respostasCorretas = {"A","B","C","D","E","E","D","C","B","A"};
            int i, j;
            string saida = "";
            lstbxRespostas.Items.Clear();

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 10; j++)
                {
                    respostas[i,j] = Interaction.InputBox($"Digite a resposta da questão {j+1} \n(COM LETRA MAIÚSCULA) " +
                        $"A, B, C, D ou E?");

                    if (respostas[i,j] == "" || respostas[i,j] == " ")
                    {
                        return; 
                    }
                    else if (respostas[i,j] == "A" || respostas[i, j] == "B" || respostas[i, j] == "C" ||
                        respostas[i, j] == "D" || respostas[i, j] == "E" )
                    {
                        if (respostas[i, j] == respostasCorretas[j])
                        {
                            saida = ($"Aluno {i+1} Correta: {respostas[i, j]}");
                        }
                        else
                        {
                            saida = ($"Aluno {i+1} Incorreta: {respostas[i, j]}, Correta: {respostasCorretas[j]}");
                        }
                        lstbxRespostas.Items.Add(saida);
                    }
                    else
                    {
                        MessageBox.Show("Digite o caracter correto ou da forma solicitada");
                        j--;
                    }
                }
            }
        }
    }
}
