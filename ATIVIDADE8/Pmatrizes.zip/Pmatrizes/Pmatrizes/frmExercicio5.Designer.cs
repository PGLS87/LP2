﻿namespace Pmatrizes
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnValidar = new System.Windows.Forms.Button();
            this.lstbxRespostas = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnValidar
            // 
            this.btnValidar.Location = new System.Drawing.Point(12, 12);
            this.btnValidar.Name = "btnValidar";
            this.btnValidar.Size = new System.Drawing.Size(188, 83);
            this.btnValidar.TabIndex = 0;
            this.btnValidar.Text = "Enviar respostas";
            this.btnValidar.UseVisualStyleBackColor = true;
            this.btnValidar.Click += new System.EventHandler(this.btnValidar_Click);
            // 
            // lstbxRespostas
            // 
            this.lstbxRespostas.FormattingEnabled = true;
            this.lstbxRespostas.ItemHeight = 16;
            this.lstbxRespostas.Location = new System.Drawing.Point(206, 12);
            this.lstbxRespostas.Name = "lstbxRespostas";
            this.lstbxRespostas.Size = new System.Drawing.Size(595, 580);
            this.lstbxRespostas.TabIndex = 1;
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(813, 605);
            this.Controls.Add(this.lstbxRespostas);
            this.Controls.Add(this.btnValidar);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnValidar;
        private System.Windows.Forms.ListBox lstbxRespostas;
    }
}