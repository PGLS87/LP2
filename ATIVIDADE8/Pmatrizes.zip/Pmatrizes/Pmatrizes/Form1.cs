﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;
           
            for(int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite números inteiros," +
                    "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = String.Join("\n", vetor);
            MessageBox.Show(auxiliar);


        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            string auxiliar;
            ArrayList nomes = new ArrayList() { "Ana","André","Beatriz","Camilla","João",
                "Joana","Otávio","Marcelo","Pedro","Thais" };
      
            nomes.Remove("Otávio");

            auxiliar = "";

            foreach (string item in nomes)
            {
                auxiliar += item + "\n";
            }
            MessageBox.Show(auxiliar);

        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            int i, j;
            string nota;
            double media = 0;
            string saida ="";

            for (i = 0; i < 20; i++)

            {
                media = 0;
                for (j = 0; j < 3; j++)
                {
            
                    nota = Interaction.InputBox("Digite a nota:");
                    if (nota == "")
                    {
                        return;
                    }
                    else if (!double.TryParse(nota, out notas[i,j]))
                    {
                        MessageBox.Show("Número inválido");
                        --j;
                    }
                    else if (notas[i, j] > 10 || notas[i, j] < 0)
                    {
                        MessageBox.Show("Número inválido");
                        --j;
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }
                media = media/3;
                saida += ($"\nAluno {i + 1} : média " + media);
            }
            MessageBox.Show(saida);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {

                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 obj4 = new frmExercicio4();
                obj4.Show();
            } 

        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {

                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 obj5 = new frmExercicio5();
                obj5.Show();
            }
        }
    }
}
